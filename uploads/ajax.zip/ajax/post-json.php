<?php

// результирующий массив
$json = array(
	'key1' => 'value1',
	'key2' => 'value2',
	'key3' => 'value3',
);

// отдаем
echo json_encode($json);

# end of file