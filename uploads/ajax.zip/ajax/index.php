<!DOCTYPE HTML>
<html lang="ru"><head>
<meta charset="UTF-8">
<title>Отправка формы на AJAX (http://maxsite.org/page/send-form-ajax)</title>
<link rel="stylesheet" href="assets/css/style.css">
<script src="assets/js/jquery.min.js"></script>
</head><body>
<div class="layout-center-wrap"><div class="layout-wrap pad50-b">

<div>См. <a href="http://maxsite.org/page/send-form-ajax">Отправка произвольной формы на AJAX без перезагрузки страницы </a></div>



<h2>Первая форма</h2>
 
<form id="my_form">

	<div class="mar10-tb"><label>Имя: <input name="f[name]"></label></div>
	<div class="mar10-tb"><label>Телефон: <input name="f[phone]"></label></div>
	<div><button type="submit">Отправить</button></div>
	
</form> 

<div id="my_message"></div>

<script> 
$('#my_form').submit(function(){
	
	$.post(
		'post.php', // адрес обработчика
		 $("#my_form").serialize(), // отправляемые данные  		
		
		function(msg) { // получен ответ сервера  
			$('#my_form').hide('slow');
			$('#my_message').html(msg);
		}
	);
	
	return false;
});
</script> 


<hr>


<h2>Вторая форма</h2>

<div><button type="button" id="my_form_send2">Отправить</button></div>
 
<form id="my_form2">
	<div class="mar10-tb"><label>Имя: <input name="f[name]"></label></div>
	<div class="mar10-tb"><label>Телефон: <input name="f[phone]"></label></div>
</form> 
 
<div id="my_message2"></div>

<script> 
$('#my_form_send2').click(function(){
	
	$.post(
		'post.php', // адрес обработчика
		 $("#my_form2").serialize(), // отправляемые данные  		
		
		function(msg) { // получен ответ сервера  
			$('#my_form2').hide('slow');
			$('#my_message2').html(msg);
		}
	);
	
});
</script> 


<hr>

 
<h2>Третья форма (без формы)</h2>

<div class="mar10-tb"><label>Имя: <input name="f[name]" id="i1"></label></div>
<div class="mar10-tb"><label>Телефон: <input name="f[phone]" id="i2"></label></div>
<div><a href="#" id="my_send3">Отправить</a></div>
  
<div id="my_message3"></div>

<script>
$('#my_send3').click(function(){
	$.post(
		'post-json.php', // адрес обработчика		
		{
			name: $('#i1').val(), 
			phone: $('#i2').val()
		},
		
		function(msg) { // получен ответ сервера — это json! 
			console.log(msg); // в консоль для контроля
			$('#my_message3').html(msg.key1);
		},
		'json'
	);
	
	return false;
});
</script> 


<hr>


<h2>Форма на email</h2>
 
<form id="my_form_email">
	<div class="mar10-tb"><label>Имя: <input type="text" name="f[name]" required></label></div>
	<div class="mar10-tb"><label>Email: <input type="email" name="f[email]" required></label></div>
	<div><button type="submit">Отправить</button></div>
</form> 
 
<div id="my_message_email"></div>

<script> 
$('#my_form_email').submit(function(){
	
	$.post(
		'post-email.php', // адрес обработчика
		 $("#my_form_email").serialize(), // отправляемые данные  		
		
		function(msg) { // получен ответ сервера  
			// $('#my_form_email').hide('slow');
			$('#my_message_email').html(msg);
		}
	);
	
	return false;
});
</script> 



</div></div>
<link rel="stylesheet" href="assets/css/-lazy.css">
<link rel="stylesheet" href="assets/css/fontawesome.css">
</body></html>