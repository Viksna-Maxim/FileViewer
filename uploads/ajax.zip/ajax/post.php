<?php

if (!$_POST) exit('No direct script access allowed');

echo '<pre>';
print_r($_POST);
echo '</pre>';

# end of file